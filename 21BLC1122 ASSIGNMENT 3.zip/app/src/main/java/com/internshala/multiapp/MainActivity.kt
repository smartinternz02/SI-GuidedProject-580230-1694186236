package com.internshala.multiapp

import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webView)
        webView.webViewClient = WebViewClient()

        amazonButton.setOnClickListener {
            loadWebsite("https://www.amazon.com")
        }

        flipkartButton.setOnClickListener {
            loadWebsite("https://www.flipkart.com")
        }

        myntraButton.setOnClickListener {
            loadWebsite("https://www.myntra.com")
        }
    }

    private fun loadWebsite(url: String) {
        webView.visibility = View.VISIBLE
        webView.loadUrl(url)
    }

    // Handle the back button to navigate within the WebView
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
